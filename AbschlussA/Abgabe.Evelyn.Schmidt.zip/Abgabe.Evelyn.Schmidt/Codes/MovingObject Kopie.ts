namespace Spaceworld {
    export class MovingObject {
        x: number;
        y: number;
        
     
        checkPosition(): void {
            //    
        }
        
        move(): void {
            //
        }
        
        draw(): void {
            //
        }
 
        
    } 
}