var Spaceworld;
(function (Spaceworld) {
    var MovingObject = (function () {
        function MovingObject() {
        }
        MovingObject.prototype.checkPosition = function () {
            //    
        };
        MovingObject.prototype.move = function () {
            //
        };
        MovingObject.prototype.draw = function () {
            //
        };
        return MovingObject;
    }());
    Spaceworld.MovingObject = MovingObject;
})(Spaceworld || (Spaceworld = {}));
//# sourceMappingURL=MovingObject.js.map